"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function FarmAdminPage() {

  const [farmName,setFarmName] = useState("");
  const [username,setUsername] = useState("");
  const [password,setPassword] = useState("");

  const [farms,setFarms] = useState<any[]>([]);

  async function loadFarms() {

    const { data } = await supabase
      .from("farms")
      .select("*")
      .order("created_at",{ ascending:false });

    if(data){
      setFarms(data);
    }
  }

  useEffect(()=>{
    loadFarms();
  },[]);

  async function createFarm(){

    if(!farmName || !username || !password){
      alert("Complete all fields");
      return;
    }

    const { error } = await supabase
      .from("farms")
      .insert([
        {
          farm_name:farmName,
          username:username,
          password:password
        }
      ]);

    if(error){
      alert(error.message);
      return;
    }

    alert("Farm Created");

    setFarmName("");
    setUsername("");
    setPassword("");

    loadFarms();
  }

  return(
    <div
      style={{
        minHeight:"100vh",
        background:"#06071A",
        color:"white",
        padding:"40px"
      }}
    >

      <h1
        style={{
          fontSize:"40px",
          fontWeight:"900",
          marginBottom:"30px"
        }}
      >
        Farm Admin
      </h1>

      <div
        style={{
          background:"rgba(255,255,255,0.05)",
          padding:"20px",
          borderRadius:"20px",
          maxWidth:"500px",
          marginBottom:"40px"
        }}
      >

        <input
          placeholder="Farm Name"
          value={farmName}
          onChange={(e)=>setFarmName(e.target.value)}
          style={inputStyle}
        />

        <input
          placeholder="Username"
          value={username}
          onChange={(e)=>setUsername(e.target.value)}
          style={inputStyle}
        />

        <input
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
          style={inputStyle}
        />

        <button
          onClick={createFarm}
          style={buttonStyle}
        >
          Create Farm
        </button>

      </div>

      <div>

        {farms.map((farm)=>(
          <div
            key={farm.id}
            style={{
              background:"rgba(255,255,255,0.04)",
              padding:"20px",
              borderRadius:"20px",
              marginBottom:"15px"
            }}
          >
            <h3>{farm.farm_name}</h3>

            <p>Username: {farm.username}</p>

          </div>
        ))}

      </div>

    </div>
  );
}

const inputStyle = {
  width:"100%",
  padding:"14px",
  marginBottom:"15px",
  borderRadius:"12px",
  border:"none",
  background:"rgba(255,255,255,0.08)",
  color:"white"
};

const buttonStyle = {
  width:"100%",
  padding:"14px",
  borderRadius:"12px",
  border:"none",
  background:"#C9A96E",
  color:"#06071A",
  fontWeight:"900",
  cursor:"pointer"
};