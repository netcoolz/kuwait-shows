"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import {
  Plus,
  LogOut,
  Settings,
  Globe,
  BadgeCheck,
  Pencil,
  Trash2,
  Save,
  X,
  Upload
} from "lucide-react";

import { supabase } from "@/lib/supabase";

const HORSE_COLORS = [
  "Grey",
  "Bay",
  "Chestnut",
  "Black"
];

const HORSE_GENDERS = [
  "Male",
  "Female"
];

const HEALTH_OPTIONS = [
  "Melanomas",
  "Laminitis",
  "Fertility problems",
  "Pigmentation loss",
  "Epilepsy",
  "Ovarian tumor",
  "Guttural pouch tympany",
  "Other"
];

function calculateAge(date:string){

  if(!date){
    return 0;
  }

  const birth = new Date(date);

  const today = new Date();

  let age =
    today.getFullYear() - birth.getFullYear();

  const monthDiff =
    today.getMonth() - birth.getMonth();

  if(
    monthDiff < 0 ||
    (
      monthDiff === 0 &&
      today.getDate() < birth.getDate()
    )
  ){
    age--;
  }

  return age;
}

function getHorseType(
  gender:string,
  birthDate:string
){

  const age = calculateAge(birthDate);

  if(gender === "Male"){

    return age <= 3
      ? "Colt"
      : "Stallion";
  }

  return age <= 3
    ? "Filly"
    : "Mare";
}

export default function FarmDashboard(){

  const router = useRouter();

  const [farm,setFarm] = useState<any>(null);

  const [horses,setHorses] = useState<any[]>([]);

  const [loading,setLoading] = useState(true);

  const [showAddHorse,setShowAddHorse] = useState(false);

  const [showSettings,setShowSettings] = useState(false);

  const [uploading,setUploading] = useState(false);

  const [uploadingLogo,setUploadingLogo] = useState(false);

  const [language,setLanguage] =
    useState<"en"|"ar">("en");

  const [horseForm,setHorseForm] = useState({
    name:"",
    nameAr:"",
    image:"",
    birthDate:"",
    color:"",
    gender:"",
    sire:"",
    dam:"",
    strain:"",
    family:"",
    health:"",
    otherHealth:"",
    breeder:"",
    country:"",
    achievements:"",
    notes:"",
  });

  const [farmForm,setFarmForm] = useState({
    display_name:"",
    country:"",
    instagram:"",
    website:"",
    bio:"",
    logo:"",
  });

  useEffect(()=>{

    const saved = localStorage.getItem("farm");

    if(!saved){

      router.push("/farmlogin");

      return;
    }

    const parsed = JSON.parse(saved);

    loadFarm(parsed.id);

    loadHorses(parsed.id);

  },[]);

  async function loadFarm(id:string){

    const { data } = await supabase
      .from("farms")
      .select("*")
      .eq("id",id)
      .single();

    if(data){

      setFarm(data);

      setFarmForm({
        display_name:data.display_name || "",
        country:data.country || "",
        instagram:data.instagram || "",
        website:data.website || "",
        bio:data.bio || "",
        logo:data.logo || "",
      });
    }

    setLoading(false);
  }

  async function loadHorses(id:string){

    const { data } = await supabase
      .from("horses")
      .select("*")
      .eq("farm_id",id)
      .order("created_at",{ ascending:false });

    if(data){
      setHorses(data);
    }
  }

  async function uploadHorseImage(file:any){

    if(!file){
      return;
    }

    setUploading(true);

    const ext = file.name.split(".").pop();

    const fileName = `horse-${Date.now()}.${ext}`;

    const { error } = await supabase.storage
      .from("horse-images")
      .upload(fileName,file);

    if(error){

      alert(error.message);

      setUploading(false);

      return;
    }

    const { data } = supabase.storage
      .from("horse-images")
      .getPublicUrl(fileName);

    setHorseForm({
      ...horseForm,
      image:data.publicUrl
    });

    setUploading(false);
  }

  async function uploadFarmLogo(file:any){

    if(!file){
      return;
    }

    setUploadingLogo(true);

    const ext = file.name.split(".").pop();

    const fileName = `farm-${Date.now()}.${ext}`;

    const { error } = await supabase.storage
      .from("farm-logos")
      .upload(fileName,file);

    if(error){

      alert(error.message);

      setUploadingLogo(false);

      return;
    }

    const { data } = supabase.storage
      .from("farm-logos")
      .getPublicUrl(fileName);

    setFarmForm({
      ...farmForm,
      logo:data.publicUrl
    });

    setUploadingLogo(false);
  }

  async function saveHorse(){

    if(!horseForm.name){

      alert("Horse name required");

      return;
    }

    const healthValue =
      horseForm.health === "Other"
        ? horseForm.otherHealth
        : horseForm.health;

    const horseType = getHorseType(
      horseForm.gender,
      horseForm.birthDate
    );

    const { error } = await supabase
      .from("horses")
      .insert([
        {
          farm_id:farm.id,

          name:horseForm.name,

          name_ar:horseForm.nameAr,

          image:horseForm.image,

          birth_date:horseForm.birthDate,

          color:horseForm.color,

          gender:horseForm.gender,

          sex:horseType,

          sire:horseForm.sire,

          dam:horseForm.dam,

          strain:horseForm.strain,

          family:horseForm.family,

          breeder:horseForm.breeder,

          country:horseForm.country,

          achievements:horseForm.achievements,

          notes:horseForm.notes,

          health:healthValue
            ? [healthValue]
            : []
        }
      ]);

    if(error){

      alert(error.message);

      return;
    }

    setShowAddHorse(false);

    setHorseForm({
      name:"",
      nameAr:"",
      image:"",
      birthDate:"",
      color:"",
      gender:"",
      sire:"",
      dam:"",
      strain:"",
      family:"",
      health:"",
      otherHealth:"",
      breeder:"",
      country:"",
      achievements:"",
      notes:"",
    });

    loadHorses(farm.id);
  }

  async function saveFarmSettings(){

    const { error } = await supabase
      .from("farms")
      .update({
        display_name:farmForm.display_name,
        country:farmForm.country,
        instagram:farmForm.instagram,
        website:farmForm.website,
        bio:farmForm.bio,
        logo:farmForm.logo,
      })
      .eq("id",farm.id);

    if(error){

      alert(error.message);

      return;
    }

    alert("Farm updated");

    setShowSettings(false);

    loadFarm(farm.id);
  }

  async function deleteHorse(id:string){

    if(!confirm("Delete horse?")){
      return;
    }

    await supabase
      .from("horses")
      .delete()
      .eq("id",id);

    loadHorses(farm.id);
  }

  function logout(){

    localStorage.removeItem("farm");

    router.push("/farmlogin");
  }

  const stats = useMemo(()=>{

    return{

      total:horses.length,

      stallions:horses.filter(
        x=>getHorseType(
          x.gender,
          x.birth_date
        ) === "Stallion"
      ).length,

      mares:horses.filter(
        x=>getHorseType(
          x.gender,
          x.birth_date
        ) === "Mare"
      ).length,

      foals:horses.filter(
        x=>calculateAge(x.birth_date) <= 3
      ).length,
    };

  },[horses]);

  if(loading){
    return null;
  }

  return(
    <div
      style={{
        minHeight:"100vh",
        background:"#06071A",
        color:"white"
      }}
    >

      <div
        style={{
          width:"260px",
          position:"fixed",
          top:0,
          left:0,
          bottom:0,
          background:"rgba(255,255,255,0.04)",
          borderRight:"1px solid rgba(255,255,255,0.08)",
          padding:"30px 20px",
          backdropFilter:"blur(20px)",
          zIndex:100,
          display:"flex",
          flexDirection:"column"
        }}
      >

        <div
          style={{
            textAlign:"center",
            marginBottom:"40px"
          }}
        >

          <img
            src={
              farm?.logo ||
              "https://placehold.co/200x200/png"
            }
            style={{
              width:"110px",
              height:"110px",
              borderRadius:"999px",
              objectFit:"cover",
              marginBottom:"15px",
              border:"4px solid rgba(201,169,110,0.4)"
            }}
          />

          <h2
            style={{
              fontSize:"24px",
              fontWeight:"900"
            }}
          >
            {farm?.display_name || farm?.farm_name}
          </h2>

          <div
            style={{
              color:"rgba(255,255,255,0.45)",
              marginTop:"5px"
            }}
          >
            {farm?.country || "Kuwait"}
          </div>

        </div>

        <button
          onClick={()=>setShowAddHorse(true)}
          style={sidebarBtn}
        >
          <Plus size={18}/>
          Add Horse
        </button>

        <button
          onClick={()=>setShowSettings(true)}
          style={sidebarBtn}
        >
          <Settings size={18}/>
          Farm Settings
        </button>

<button
  onClick={() => router.push("/analytics")}
  style={{
    ...sidebarBtn,
    background:"rgba(201,169,110,0.12)",
    border:"1px solid rgba(201,169,110,0.25)",
    color:"#C9A96E"
  }}
>
  📊 Analytics
</button>
<button

  onClick={()=>

    setLanguage(

      language === "en"

        ? "ar"

        : "en"

    )

  }

  style={sidebarBtn}

>

  🌐 {language === "en"

    ? "العربية"

    : "English"}

</button>
        <button
          onClick={logout}
          style={{
            ...sidebarBtn,
            marginTop:"auto",
            background:"rgba(251,113,133,0.15)",
            color:"#fb7185"
          }}
        >
          <LogOut size={18}/>
          Logout
        </button>

      </div>

      <div
        style={{
          marginLeft:"260px",
          padding:"40px"
        }}
      >

        <div
          style={{
            marginBottom:"35px"
          }}
        >

          <h1
            style={{
              fontSize:"52px",
              fontWeight:"900",
              marginBottom:"10px",
              background:"linear-gradient(to right,#fff,#C9A96E)",
              WebkitBackgroundClip:"text",
              WebkitTextFillColor:"transparent"
            }}
          >
            {farm?.display_name || farm?.farm_name}
          </h1>

          <p
            style={{
              color:"rgba(255,255,255,0.45)",
              maxWidth:"700px",
              lineHeight:"1.8"
            }}
          >
            {farm?.bio || "Arabian horse breeding platform"}
          </p>

        </div>

        <div
          style={{
            display:"grid",
            gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",
            gap:"20px",
            marginBottom:"35px"
          }}
        >

          <StatCard
            title="Total Horses"
            value={stats.total}
            color="#C9A96E"
          />

          <StatCard
            title="Stallions"
            value={stats.stallions}
            color="#60a5fa"
          />

          <StatCard
            title="Mares"
            value={stats.mares}
            color="#f472b6"
          />

          <StatCard
            title="Foals"
            value={stats.foals}
            color="#34d399"
          />

        </div>

        <div
          style={{
            display:"grid",
            gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",
            gap:"20px"
          }}
        >

          {horses.map((horse)=>(

            <div
              key={horse.id}
              style={{
                background:"rgba(255,255,255,0.04)",
                border:"1px solid rgba(255,255,255,0.08)",
                borderRadius:"28px",
                overflow:"hidden"
              }}
            >

              <img
                src={
                  horse.image ||
                  "https://placehold.co/800x500/png"
                }
                style={{
                  width:"100%",
                  height:"220px",
                  objectFit:"cover"
                }}
              />

              <div
                style={{
                  padding:"20px"
                }}
              >

                <div
                  style={{
                    display:"flex",
                    justifyContent:"space-between",
                    marginBottom:"15px"
                  }}
                >

                  <div>

                    <h2
                      style={{
                        fontSize:"24px",
                        fontWeight:"900"
                      }}
                    >
                      {horse.name}
                    </h2>

                    <div
                      style={{
                        color:"rgba(255,255,255,0.45)"
                      }}
                    >
                      {horse.name_ar}
                    </div>

                  </div>

                  <div
                    style={{
                      background:"#C9A96E",
                      color:"#06071A",
                      padding:"8px 12px",
                      borderRadius:"12px",
                      fontWeight:"900",
                      height:"fit-content"
                    }}
                  >
                    {calculateAge(horse.birth_date)}Y
                  </div>

                </div>

                <div
                  style={{
                    display:"grid",
                    gridTemplateColumns:"1fr 1fr",
                    gap:"10px",
                    color:"rgba(255,255,255,0.7)",
                    marginBottom:"20px"
                  }}
                >

                  <div>Color: {horse.color}</div>

                  <div>
                    Type: {
                      getHorseType(
                        horse.gender,
                        horse.birth_date
                      )
                    }
                  </div>

                  <div>Gender: {horse.gender}</div>

                  <div>Sire: {horse.sire}</div>

                  <div>Dam: {horse.dam}</div>

                  <div>Strain: {horse.strain}</div>

                  <div>Family: {horse.family}</div>

                  <div>Breeder: {horse.breeder}</div>

                  <div>Country: {horse.country}</div>

                </div>

                <div
                  style={{
                    marginBottom:"15px",
                    color:"rgba(255,255,255,0.6)"
                  }}
                >
                  Birth:
                  {
                    horse.birth_date
                      ? new Date(
                          horse.birth_date
                        ).toLocaleDateString()
                      : "-"
                  }
                </div>

                {
                  horse.health?.length > 0 && (

                    <div
                      style={{
                        marginBottom:"15px"
                      }}
                    >

                      <div
                        style={{
                          color:"#C9A96E",
                          fontWeight:"800",
                          marginBottom:"8px"
                        }}
                      >
                        Health
                      </div>

                      <div
                        style={{
                          display:"flex",
                          flexWrap:"wrap",
                          gap:"8px"
                        }}
                      >

                        {horse.health.map(
                          (
                            item:any,
                            index:number
                          )=>(

                            <div
                              key={index}
                              style={{
                                padding:"8px 12px",
                                borderRadius:"999px",
                                background:"rgba(251,113,133,0.12)",
                                color:"#fb7185",
                                fontSize:"13px",
                                fontWeight:"700"
                              }}
                            >
                              {item}
                            </div>

                          )
                        )}

                      </div>

                    </div>

                  )
                }

                <div
                  style={{
                    display:"flex",
                    gap:"10px"
                  }}
                >

                  <button
                    style={actionBtn}
                  >
                    <Pencil size={16}/>
                  </button>

                  <button
                    onClick={()=>
                      deleteHorse(horse.id)
                    }
                    style={{
                      ...actionBtn,
                      background:"rgba(251,113,133,0.15)",
                      color:"#fb7185"
                    }}
                  >
                    <Trash2 size={16}/>
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>

      {showAddHorse && (

        <Modal
          title="Add Horse"
          onClose={()=>
            setShowAddHorse(false)
          }
        >

          <div style={grid2}>

            <Input
              placeholder="Horse Name"
              value={horseForm.name}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  name:v
                })
              }
            />

            <Input
              placeholder="Horse Arabic Name"
              value={horseForm.nameAr}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  nameAr:v
                })
              }
            />

            <div>

              <label style={uploadLabel}>

                <Upload size={18}/>

                {
                  uploading
                    ? "Uploading..."
                    : "Upload Horse Image"
                }

                <input
                  type="file"
                  hidden
                  accept="image/*"
                  onChange={(e)=>{

                    const file =
                      e.target.files?.[0];

                    if(file){
                      uploadHorseImage(file);
                    }

                  }}
                />

              </label>

              {horseForm.image && (

                <img
                  src={horseForm.image}
                  style={{
                    width:"100%",
                    height:"180px",
                    objectFit:"cover",
                    borderRadius:"18px",
                    marginTop:"10px"
                  }}
                />

              )}

            </div>

            <Input
              placeholder="Birth Date"
              type="date"
              value={horseForm.birthDate}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  birthDate:v
                })
              }
            />

            <select
              value={horseForm.color}
              onChange={(e)=>
                setHorseForm({
                  ...horseForm,
                  color:e.target.value
                })
              }
              style={selectStyle}
            >

              <option
                value=""
                style={{
                  background:"#0B0C20"
                }}
              >
                Select Color
              </option>

              {HORSE_COLORS.map((item)=>(

                <option
                  key={item}
                  value={item}
                  style={{
                    background:"#0B0C20"
                  }}
                >
                  {item}
                </option>

              ))}

            </select>

            <select
              value={horseForm.gender}
              onChange={(e)=>
                setHorseForm({
                  ...horseForm,
                  gender:e.target.value
                })
              }
              style={selectStyle}
            >

              <option
                value=""
                style={{
                  background:"#0B0C20"
                }}
              >
                Select Gender
              </option>

              {HORSE_GENDERS.map((item)=>(

                <option
                  key={item}
                  value={item}
                  style={{
                    background:"#0B0C20"
                  }}
                >
                  {item}
                </option>

              ))}

            </select>

            <Input
              placeholder="Sire"
              value={horseForm.sire}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  sire:v
                })
              }
            />

            <Input
              placeholder="Dam"
              value={horseForm.dam}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  dam:v
                })
              }
            />

            <Input
              placeholder="Strain"
              value={horseForm.strain}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  strain:v
                })
              }
            />

            <Input
              placeholder="Family"
              value={horseForm.family}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  family:v
                })
              }
            />

            <Input
              placeholder="Breeder"
              value={horseForm.breeder}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  breeder:v
                })
              }
            />

            <Input
              placeholder="Country"
              value={horseForm.country}
              onChange={(v:any)=>
                setHorseForm({
                  ...horseForm,
                  country:v
                })
              }
            />

          </div>

          <select
            value={horseForm.health}
            onChange={(e)=>
              setHorseForm({
                ...horseForm,
                health:e.target.value
              })
            }
            style={{
              ...selectStyle,
              marginTop:"15px"
            }}
          >

            <option
              value=""
              style={{
                background:"#0B0C20"
              }}
            >
              Select Health Condition
            </option>

            {HEALTH_OPTIONS.map((item)=>(

              <option
                key={item}
                value={item}
                style={{
                  background:"#0B0C20"
                }}
              >
                {item}
              </option>

            ))}

          </select>

          {
            horseForm.health === "Other" && (

              <Input
                placeholder="Other Disease"
                value={horseForm.otherHealth}
                onChange={(v:any)=>
                  setHorseForm({
                    ...horseForm,
                    otherHealth:v
                  })
                }
              />

            )
          }

          <textarea
            value={horseForm.achievements}
            onChange={(e)=>
              setHorseForm({
                ...horseForm,
                achievements:e.target.value
              })
            }
            placeholder="Achievements"
            style={textareaStyle}
          />

          <textarea
            value={horseForm.notes}
            onChange={(e)=>
              setHorseForm({
                ...horseForm,
                notes:e.target.value
              })
            }
            placeholder="Notes"
            style={textareaStyle}
          />

          <button
            onClick={saveHorse}
            style={saveBtn}
          >
            <Save size={18}/>
            Save Horse
          </button>

        </Modal>

      )}

      {showSettings && (

        <Modal
          title="Farm Settings"
          onClose={()=>
            setShowSettings(false)
          }
        >

          <div style={grid2}>

            <Input
              placeholder="Display Name"
              value={farmForm.display_name}
              onChange={(v:any)=>
                setFarmForm({
                  ...farmForm,
                  display_name:v
                })
              }
            />

            <Input
              placeholder="Country"
              value={farmForm.country}
              onChange={(v:any)=>
                setFarmForm({
                  ...farmForm,
                  country:v
                })
              }
            />

            <Input
              placeholder="Instagram"
              value={farmForm.instagram}
              onChange={(v:any)=>
                setFarmForm({
                  ...farmForm,
                  instagram:v
                })
              }
            />

            <Input
              placeholder="Website"
              value={farmForm.website}
              onChange={(v:any)=>
                setFarmForm({
                  ...farmForm,
                  website:v
                })
              }
            />

            <div>

              <label style={uploadLabel}>

                <Upload size={18}/>

                {
                  uploadingLogo
                    ? "Uploading..."
                    : "Upload Farm Logo"
                }

                <input
                  type="file"
                  hidden
                  accept="image/*"
                  onChange={(e)=>{

                    const file =
                      e.target.files?.[0];

                    if(file){
                      uploadFarmLogo(file);
                    }

                  }}
                />

              </label>

              {farmForm.logo && (

                <img
                  src={farmForm.logo}
                  style={{
                    width:"100%",
                    height:"180px",
                    objectFit:"cover",
                    borderRadius:"18px",
                    marginTop:"10px"
                  }}
                />

              )}

            </div>

          </div>

          <textarea
            value={farmForm.bio}
            onChange={(e)=>
              setFarmForm({
                ...farmForm,
                bio:e.target.value
              })
            }
            placeholder="Farm Bio"
            style={textareaStyle}
          />

          <button
            onClick={saveFarmSettings}
            style={saveBtn}
          >
            <Save size={18}/>
            Save Settings
          </button>

        </Modal>

      )}

    </div>
  );
}

function StatCard({
  title,
  value,
  color
}:any){

  return(
    <div
      style={{
        background:"rgba(255,255,255,0.04)",
        border:"1px solid rgba(255,255,255,0.08)",
        borderRadius:"28px",
        padding:"25px"
      }}
    >

      <div
        style={{
          color:"rgba(255,255,255,0.45)",
          marginBottom:"10px"
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize:"52px",
          fontWeight:"900",
          color
        }}
      >
        {value}
      </div>

    </div>
  );
}

function Modal({
  children,
  title,
  onClose
}:any){

  return(
    <div
      style={{
        position:"fixed",
        inset:0,
        background:"rgba(0,0,0,0.8)",
        backdropFilter:"blur(10px)",
        display:"flex",
        alignItems:"center",
        justifyContent:"center",
        zIndex:500
      }}
    >

      <div
        style={{
          width:"95%",
          maxWidth:"900px",
          background:"#0B0C20",
          borderRadius:"30px",
          padding:"30px",
          border:"1px solid rgba(255,255,255,0.08)",
          maxHeight:"90vh",
          overflowY:"auto"
        }}
      >

        <div
          style={{
            display:"flex",
            justifyContent:"space-between",
            marginBottom:"25px"
          }}
        >

          <h2
            style={{
              fontSize:"28px",
              fontWeight:"900"
            }}
          >
            {title}
          </h2>

          <button
            onClick={onClose}
            style={iconBtn}
          >
            <X size={18}/>
          </button>

        </div>

        {children}

      </div>

    </div>
  );
}

function Input({
  value,
  onChange,
  placeholder,
  type="text"
}:any){

  return(
    <input
      type={type}
      value={value}
      onChange={(e)=>
        onChange(e.target.value)
      }
      placeholder={placeholder}
      style={{
        width:"100%",
        background:"rgba(255,255,255,0.06)",
        border:"1px solid rgba(255,255,255,0.08)",
        borderRadius:"18px",
        padding:"15px",
        color:"white"
      }}
    />
  );
}

const sidebarBtn:any = {
  width:"100%",
  display:"flex",
  alignItems:"center",
  gap:"12px",
  padding:"15px",
  borderRadius:"18px",
  border:"none",
  background:"rgba(255,255,255,0.05)",
  color:"white",
  fontWeight:"800",
  marginBottom:"12px",
  cursor:"pointer"
};

const linkBtn:any = {
  display:"flex",
  alignItems:"center",
  gap:"10px",
  padding:"12px 18px",
  borderRadius:"14px",
  background:"rgba(255,255,255,0.06)",
  color:"white",
  textDecoration:"none",
  fontWeight:"700"
};

const actionBtn:any = {
  width:"44px",
  height:"44px",
  borderRadius:"14px",
  border:"none",
  background:"rgba(255,255,255,0.06)",
  color:"white",
  cursor:"pointer",
  display:"flex",
  alignItems:"center",
  justifyContent:"center"
};

const saveBtn:any = {
  marginTop:"20px",
  width:"100%",
  padding:"16px",
  borderRadius:"18px",
  border:"none",
  background:"#C9A96E",
  color:"#06071A",
  fontWeight:"900",
  fontSize:"16px",
  cursor:"pointer",
  display:"flex",
  alignItems:"center",
  justifyContent:"center",
  gap:"10px"
};

const iconBtn:any = {
  width:"42px",
  height:"42px",
  borderRadius:"14px",
  border:"none",
  background:"rgba(255,255,255,0.06)",
  color:"white",
  cursor:"pointer",
  display:"flex",
  alignItems:"center",
  justifyContent:"center"
};

const grid2:any = {
  display:"grid",
  gridTemplateColumns:"1fr 1fr",
  gap:"15px"
};

const uploadLabel:any = {
  width:"100%",
  minHeight:"56px",
  background:"rgba(255,255,255,0.06)",
  border:"1px dashed rgba(255,255,255,0.2)",
  borderRadius:"18px",
  padding:"15px",
  color:"white",
  display:"flex",
  alignItems:"center",
  justifyContent:"center",
  gap:"10px",
  cursor:"pointer"
};

const textareaStyle:any = {
  width:"100%",
  minHeight:"120px",
  marginTop:"15px",
  borderRadius:"18px",
  padding:"15px",
  background:"rgba(255,255,255,0.06)",
  border:"1px solid rgba(255,255,255,0.08)",
  color:"white"
};

const selectStyle:any = {
  width:"100%",
  background:"rgba(255,255,255,0.06)",
  border:"1px solid rgba(255,255,255,0.08)",
  borderRadius:"18px",
  padding:"15px",
  color:"white"
}; 